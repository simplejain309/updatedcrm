from django.apps import AppConfig


class CrmappConfig(AppConfig):
    name = 'crmApp'
